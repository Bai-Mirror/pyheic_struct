# pyheic-struct

Primary documentation now lives in `docs/README.md` (Chinese) and `docs/README.en.md` (English).

For installation and usage details, please consult those files.
